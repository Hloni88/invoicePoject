
create table invoice
(
   id bigint not null  PRIMARY KEY AUTO_INCREMENT,
   client varchar(255) not null,
   vat_rate bigint not null,
   invoice_date date 
);

create table line_item
(
id bigint not null  PRIMARY KEY AUTO_INCREMENT,
quantity bigint not null,
description varchar(255) not null,
unit_price double not null,
invoice_id bigint not null,
foreign key (invoice_id) references invoice(id)
);

--ALTER TABLE invoice ADD PRIMARY KEY (id);
--ALTER TABLE line_item ADD PRIMARY KEY (id);


