insert into invoice(ID, CLIENT, INVOICE_DATE, VAT_RATE)
values(1,'hloni','2018-10-02',15);


insert into invoice(ID, CLIENT, INVOICE_DATE, VAT_RATE)
values(2,'Kate','2018-10-08',15);

insert into invoice(ID, CLIENT, INVOICE_DATE, VAT_RATE)
values(3,'max','2018-10-04',16);




insert into line_item(ID, DESCRIPTION,QUANTITY, UNIT_PRICE, INVOICE_ID)
values(1,'Test Product', 3, 12.45, 1);
insert into line_item(ID, DESCRIPTION,QUANTITY, UNIT_PRICE, INVOICE_ID)
values(2,'Test ProductTwo', 2, 12.45, 1);
insert into line_item(ID, DESCRIPTION,QUANTITY, UNIT_PRICE, INVOICE_ID)
values(3,'Test ProductThree', 1, 12.45, 1);

insert into line_item(ID, DESCRIPTION,QUANTITY, UNIT_PRICE, INVOICE_ID)
values(4,'Test Product', 3, 09.45, 2);
insert into line_item(ID, DESCRIPTION,QUANTITY, UNIT_PRICE, INVOICE_ID)
values(5,'Test ProductTwo', 2, 10.45, 3);
insert into line_item(ID, DESCRIPTION,QUANTITY, UNIT_PRICE, INVOICE_ID)
values(6,'Test ProductThree', 1, 11.45, 3);



