package za.co.digitalplatoon.invoiceservice.entities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "LINE_ITEM")
public class LineItem implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id",unique=true,nullable=false)
	private long id;
	
	@Column(name = "QUANTITY")
	private long quantity;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "UNIT_PRICE")
	private BigDecimal unitPrice;
	@ManyToOne
	@JoinColumn(name= "INVOICE_ID")
	private Invoice invoice;
	

	public LineItem() {
		super();
	}

	public LineItem(long id, long quantity, String description, BigDecimal unitPrice, Invoice invoice) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.description = description;
		this.unitPrice = unitPrice;
		this.invoice = invoice;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public BigDecimal getLineItemTotal() {
		BigDecimal total = unitPrice.multiply(new BigDecimal(""+quantity));
		return total;
	}

	
}
