package za.co.digitalplatoon.invoiceservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import za.co.digitalplatoon.invoiceservice.entities.Invoice;
@Repository
public interface  InvoiveRepository extends JpaRepository<Invoice, Long> {

}
