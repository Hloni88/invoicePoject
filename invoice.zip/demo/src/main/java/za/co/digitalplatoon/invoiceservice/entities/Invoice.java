package za.co.digitalplatoon.invoiceservice.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Id;

@Entity
@Table(name = "INVOICE")
public class Invoice implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id",unique=true,nullable=false)
	private Long id;
	
	@Column(name = "CLIENT")
	private String client;
	
	@Column(name = "VAT_RATE")
	private long vatRate;
	
	@Column(name = "INVOICE_DATE")
	private Date invoiceDate;
	
	@OneToMany(mappedBy="invoice")
	private List<LineItem> lineitems;
	
	@Transient
	private BigDecimal total =BigDecimal.ZERO;
	@Transient
	private BigDecimal subTotal = BigDecimal.ZERO;
	@Transient
	private BigDecimal vatAmount =BigDecimal.ZERO;
	
	
	
	public Invoice() {
		super();
	}

	public Invoice(Long id, String client, long vatRate, Date invoiceDate, List<LineItem> lineitems, BigDecimal total,
			BigDecimal subTotal, BigDecimal vatAmount) {
		super();
		this.id = id;
		this.client = client;
		this.vatRate = vatRate;
		this.invoiceDate = invoiceDate;
		this.lineitems = lineitems;
		this.total = total;
		this.subTotal = subTotal;
		this.vatAmount = vatAmount;
	}
	
	

	public Invoice(Long id, String client, long vatRate, Date invoiceDate, List<LineItem> lineitems) {
		super();
		this.id = id;
		this.client = client;
		this.vatRate = vatRate;
		this.invoiceDate = invoiceDate;
		this.lineitems = lineitems;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public long getVatRate() {
		return vatRate;
	}

	public void setVatRate(long vatRate) {
		this.vatRate = vatRate;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public List<LineItem> getLineitems() {
		return lineitems;
	}

	public void setLineitems(List<LineItem> lineitems) {
		this.lineitems = lineitems;
	}
	
	public BigDecimal getVat() {
		vatAmount = new BigDecimal(""+(getTotal().doubleValue() * vatRate)/100);
		return vatAmount;
	}
	
	public BigDecimal getSubTotal() {
		subTotal = new BigDecimal(""+(getTotal().doubleValue() - getVat().doubleValue())); 
		return subTotal;
	}
	
	public BigDecimal getTotal() {
		total = BigDecimal.ZERO;
		double totalDouble = 0.0;
		for(LineItem lineItem: lineitems) {
			totalDouble = total.doubleValue() + lineItem.getLineItemTotal().doubleValue();
		}
		total = new BigDecimal(""+totalDouble);
		return total;
	}

}
