package za.co.digitalplatoon.invoiceservice.service.invoice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootApplication
@ComponentScan(basePackages = {"za.co.digitalplatoon.invoiceservice.controller"})
@EnableJpaRepositories("za.co.digitalplatoon.invoiceservice.repository")
@EntityScan("za.co.digitalplatoon.invoiceservice.entities")  
public class InvoiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvoiceApplication.class, args);
	}
}
