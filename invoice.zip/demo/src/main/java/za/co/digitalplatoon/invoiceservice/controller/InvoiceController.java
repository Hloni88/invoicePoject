package za.co.digitalplatoon.invoiceservice.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import za.co.digitalplatoon.invoiceservice.entities.Invoice;
import za.co.digitalplatoon.invoiceservice.repository.InvoiveRepository;

@RestController
@RequestMapping("/")
public class InvoiceController {

	private final InvoiveRepository invoiceRepository;
	
	public InvoiceController(InvoiveRepository invoiceRepository) {
		this.invoiceRepository = invoiceRepository;
	}

	@GetMapping(value="invoices" )
	@ResponseBody
	public List<Invoice> viewAllInvoices() {
		List<Invoice> list =invoiceRepository.findAll();
		return list;
	}
	
	@GetMapping(value="invoices/{id}" )
	public Invoice viewInvoices(@PathVariable Long id) {
		Optional<Invoice> findInvoiceById = invoiceRepository.findById(id);
		if(findInvoiceById.isPresent()) {
			return findInvoiceById.get();
		}
		return null;
	}
	
	@PostMapping("invoice" )
	public void  addInvoice(@Valid @RequestBody Invoice invoice) {
		 invoiceRepository.save(invoice);
	}
}
